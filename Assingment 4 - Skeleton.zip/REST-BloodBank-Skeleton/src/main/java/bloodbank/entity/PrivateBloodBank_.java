package bloodbank.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-03-31T23:32:01.882-0400")
@StaticMetamodel(PrivateBloodBank.class)
public class PrivateBloodBank_ extends BloodBank_ {
}
