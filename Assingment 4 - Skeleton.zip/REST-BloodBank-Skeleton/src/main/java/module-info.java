open module bloodbank {
    
	requires org.apache.logging.log4j;
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.datatype.jsr310;
    requires com.fasterxml.jackson.annotation;
    requires org.hibernate.orm.core;
    requires jakarta.jakartaee.api;
	requires jakarta.security.enterprise;
    
}